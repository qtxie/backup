<#
.SYNOPSIS Launch Developer PowerShell
.DESCRIPTION
Locates and imports a Developer PowerShell module and calls the Enter-VsDevShell cmdlet. The Developer PowerShell module
is located in one of several ways:
  1) From a path in a Visual Studio installation
  2) From the latest installation of Visual Studio (higher versions first)
  3) From the instance ID of a Visual Studio installation
  4) By selecting a Visual Studio installation from a list

By default, with no parameters, the path to this script is used to locate the Developer PowerShell module. If that fails,
then the latest Visual Studio installation is used. If both methods fail, then the user can select a Visual Studio installation
from a list.
.PARAMETER VsInstallationPath 
A path in a Visual Studio installation. The path is used to locate the Developer PowerShell module.
By default, this is the path to this script.
.PARAMETER Latest
Use the latest Visual Studio installation to locate the Developer PowerShell module.
.PARAMETER List
Display a list of Visual Studio installations to choose from. The choosen installation is used to locate the Developer PowerShell module.
.PARAMETER VsInstanceId
A Visual Studio installation instance ID. The matching installation is used to locate the Developer PowerShell module.
.PARAMETER ExcludePrerelease
Excludes Prerelease versions of Visual Studio from consideration. Applies only to Latest and List.
.PARAMETER VsWherePath
Path to the vswhere utility used to located and identify Visual Studio installations.
By default, the path is the well-known location shared by Visual Studio installations.
#>
[CmdletBinding(DefaultParameterSetName = "Default")]
param (
    [ValidateScript({Test-Path $_})]
    [Parameter(ParameterSetName = "VsInstallationPath")]
    [string]
    $VsInstallationPath = "`"$($MyInvocation.MyCommand.Definition)`"",

    [Parameter(ParameterSetName = "Latest")]
    [switch]
    $Latest,

    [Parameter(ParameterSetName = "List")]
    [switch]
    $List,

    [Parameter(ParameterSetName = "List")]
    [object[]]
    $DisplayProperties = @("displayName", "instanceId", "installationVersion", "isPrerelease", "installationName", "installDate"),

    [Parameter(ParameterSetName = "VsInstanceId", Mandatory = $true)]
    [string]
    $VsInstanceId,

    [Parameter(ParameterSetName = "Latest")]
    [Parameter(ParameterSetName = "List")]
    [switch]
    $ExcludePrerelease,

    [Parameter(ParameterSetName = "Default")]
    [Parameter(ParameterSetName = "VsInstallationPath")]
    [Parameter(ParameterSetName = "Latest")]
    [Parameter(ParameterSetName = "List")]
    [Parameter(ParameterSetName = "VsInstanceId")]
    [ValidateSet('x86','amd64','arm','arm64')]
    [string]
    $Arch,

    [Parameter(ParameterSetName = "Default")]
    [Parameter(ParameterSetName = "VsInstallationPath")]
    [Parameter(ParameterSetName = "Latest")]
    [Parameter(ParameterSetName = "List")]
    [Parameter(ParameterSetName = "VsInstanceId")]
    [ValidateSet('x86','amd64')]
    [string]
    $HostArch,

    [Parameter(ParameterSetName = "Default")]
    [Parameter(ParameterSetName = "VsInstallationPath")]
    [Parameter(ParameterSetName = "Latest")]
    [Parameter(ParameterSetName = "List")]
    [Parameter(ParameterSetName = "VsInstanceId")]
    [switch]
    $SkipAutomaticLocation,

    [ValidateScript({Test-Path $_ -PathType 'Leaf'})]
    [Parameter(ParameterSetName = "Default")]
    [Parameter(ParameterSetName = "VsInstallationPath")]
    [Parameter(ParameterSetName = "Latest")]
    [Parameter(ParameterSetName = "List")]
    [Parameter(ParameterSetName = "VsInstanceId")]
    [string]
    $VsWherePath = "`"${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe`""
)

function GetSetupConfigurations {
    param (
        $whereArgs
    )
    
    Invoke-Expression "& $VsWherePath $whereArgs -format json" | ConvertFrom-Json
}

function LaunchDevShell {
    param (
        $config
    )

    $basePath = $config.installationPath
    $instanceId = $config.instanceId

    $currModulePath = "$basePath\Common7\Tools\Microsoft.VisualStudio.DevShell.dll"
    # Prior to 16.3 the DevShell module was in a different location
    $prevModulePath = "$basePath\Common7\Tools\vsdevshell\Microsoft.VisualStudio.DevShell.dll"

    $modulePath = if (Test-Path $prevModulePath) { $prevModulePath } else { $currModulePath }

    if (Test-Path $modulePath) {
        Write-Verbose "Found at $modulePath."

        try {
            Import-Module $modulePath
        }
        catch [System.IO.FileLoadException] {
            Write-Verbose "The module has already been imported from a different installation of Visual Studio:"
            (Get-Module Microsoft.VisualStudio.DevShell).Path | Write-Verbose
        }

        $params = @{
            VsInstanceId = $instanceId
        }

        $command = Get-Command Enter-VsDevShell

        if ($SkipAutomaticLocation)
        {
            $params.SkipAutomaticLocation = $true
        }

        # -Arch is only available from 17.1
        if ($Arch -and $command.Parameters.ContainsKey("Arch"))
        {
            $params.Arch = $Arch
        }

        # -HostArch is only available from 17.1
        if ($HostArch -and $command.Parameters.ContainsKey("HostArch"))
        {
            $params.HostArch = $HostArch
        }

        # -ReportNewInstanceType is only available from 16.5
        if ($command.Parameters.ContainsKey("ReportNewInstanceType")) {
            $params.ReportNewInstanceType = "LaunchScript"
        }

        $boundParams = $PSCmdlet.MyInvocation.BoundParameters

        if ($boundParams.ContainsKey("Verbose") -and
            $boundParams["Verbose"].IsPresent)
        {
            Write-Verbose "Enter-VsDevShell Parameters:"
            $params.GetEnumerator() | ForEach-Object{
                $message = '{0} = {1}' -f $_.key, $_.value
                Write-Verbose $message
            }
        }

        Enter-VsDevShell @params
        exit
    }

    throw [System.Management.Automation.ErrorRecord]::new(
        [System.Exception]::new("Required assembly could not be located. This most likely indicates an installation error. Try repairing your Visual Studio installation. Expected location: $modulePath"),
        "DevShellModuleLoad",
        [System.Management.Automation.ErrorCategory]::NotInstalled,
        $config)
}

function VsInstallationPath {
    $setupargs = "-path $VsInstallationPath"

    Write-Verbose "Using path: $VsInstallationPath"
    $config = GetSetupConfigurations($setupargs)
    LaunchDevShell($config)
}

function Latest {
    $setupargs = "-latest"

    if (-not $ExcludePrerelease) {
        $setupargs += " -prerelease"
    }

    $config = GetSetupConfigurations($setupargs)
    LaunchDevShell($config)
}

function VsInstanceId {
    $configs = GetSetupConfigurations("-prerelease -all")
    $config = $configs | Where-Object { $_.instanceId -eq $VsInstanceId }
    if ($config) {
        Write-Verbose "Found Visual Studio installation with InstanceId of '$($config.instanceId)' and InstallationPath '$($config.installationPath)'"
        LaunchDevShell($config)
        exit
    }

    throw [System.Management.Automation.ErrorRecord]::new(
        [System.Exception]::new("Could not find an installation of Visual Studio with InstanceId '$VsInstanceId'."),
        "VsSetupInstance",
        [System.Management.Automation.ErrorCategory]::InvalidArgument,
        $config)
}

function List {
    $setupargs = "-sort"

    if (-not $ExcludePrerelease) {
        $setupargs = " -prerelease"
    }

    $configs = GetSetupConfigurations($setupargs)

    $DisplayProperties = @("#") + $DisplayProperties

    # Add an incrementing select column
    $configs = $configs |
        Sort-Object displayName, installationDate |
        ForEach-Object {$i = 0}{ $i++; $_ | Add-Member -NotePropertyName "#" -NotePropertyValue $i -PassThru }

    Write-Host "The following Visual Studio installations were found:"
    $configs | Format-Table -Property $DisplayProperties

    $selected = Read-Host "Enter '#' of the Visual Studio installation to launch DevShell. <Enter> to quit: "
    if (-not $selected) { exit }

    $config = $configs | Where-Object { $_."#" -eq $selected }

    if ($config) {
        LaunchDevShell($config)
    }
    else {
        "Invalid selection: $selected"
    }
}

function Default{
    Write-Verbose "No parameters passed to script. Trying VsInstallationPath."

    try {
        VsInstallationPath
        exit
    }
    catch {
        Write-Verbose "VsInstallationPath failed. Trying Latest."
    }

    Write-Host "Could not start Developer PowerShell using the script path."
    Write-Host "Attempting to launch from the latest Visual Studio installation."

    try {
        Latest
        exit
    }
    catch {
        Write-Verbose "Latest failed. Defaulting to List."
    }

    Write-Host "Could not start Developer PowerShell from the latest Visual Studio installation."
    Write-Host

    List
}

if ($PSCmdlet.ParameterSetName) {
    & (Get-ChildItem "Function:$($PSCmdlet.ParameterSetName)")
    exit
}
# SIG # Begin signature block
# MIInrAYJKoZIhvcNAQcCoIInnTCCJ5kCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDb5LUzcEpUmPmj
# tGFxRHdzNdMbgUh83zwUJjhG0OSVx6CCDXYwggX0MIID3KADAgECAhMzAAACURR2
# zMWFg24LAAAAAAJRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjEwOTAyMTgzMjU5WhcNMjIwOTAxMTgzMjU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDBIpXR3b1IYAMunV9ZYBVYsaA7S64mqacKy/OJUf0Lr/LW/tWlJDzJH9nFAhs0
# zzSdQQcLhShOSTUxtlwZD9dnfIcx4pZgu0VHkqQw2dVc8Ob21GBo5sVrXgEAQxZo
# rlEuAl20KpSIFLUBwoZFGFSQNSMcqPudXOw+Mhvn6rXYv/pjXIjgBntn6p1f+0+C
# 2NXuFrIwjJIJd0erGefwMg//VqUTcRaj6SiCXSY6kjO1J9P8oaRQBHIOFEfLlXQ3
# a1ATlM7evCUvg3iBprpL+j1JMAUVv+87NRApprPyV75U/FKLlO2ioDbb69e3S725
# XQLW+/nJM4ihVQ0BHadh74/lAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUMLgM7NX5EnpPfK5uU6FPvn2g/Ekw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ2NzU5NjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAIVJlff+Fp0ylEJhmvap
# NVv1bYLSWf58OqRRIDnXbHQ+FobsOwL83/ncPC3xl8ySR5uK/af4ZDy7DcDw0yEd
# mKbRLzHIfcztZVSrlsg0GKwZuaB2MEI1VizNCoZlN+HlFZa4DNm3J0LhTWrZjVR0
# M6V57cFW0GsV4NlqmtelT9JFEae7PomwgAV9xOScz8HzvbZeERcoSRp9eRsQwOw7
# 8XeCLeglqjUnz9gFM7RliCYP58Fgphtkht9LNEcErLOVW17m6/Dj75zg/IS+//6G
# FEK2oXnw5EIIWZraFHqSaee+NMgOw/R6bwB8qLv5ClOJEpGKA3XPJvS9YgOpF920
# Vu4Afqa5Rv5UJKrsxA7HOiuH4TwpkP3XQ801YLMp4LavXnvqNkX5lhFcITvb01GQ
# lcC5h+XfCv0L4hUum/QrFLavQXJ/vtirCnte5Bediqmjx3lswaTRbr/j+KX833A1
# l9NIJmdGFcVLXp1en3IWG/fjLIuP7BqPPaN7A1tzhWxL+xx9yw5vQiT1Yn14YGmw
# OzBYYLX0H9dKRLWMxMXGvo0PWEuXzYyrdDQExPf66Fq/EiRpZv2EYl2gbl9fxc3s
# qoIkyNlL1BCrvmzunkwt4cwvqWremUtqTJ2B53MbBHlf4RfvKz9NVuh5KHdr82AS
# MMjU4C8KNTqzgisqQdCy8unTMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGYwwghmIAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAJRFHbMxYWDbgsAAAAAAlEwDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIL8girP9wkOyKy7exr0F4Y00
# DoWXcV6Ag9BR5hjEA1X0MEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAjhcq6EGZBE3VODDQ3kDmqPNhC5qD7ysrZZSMzc4dkUVcVnCZequ9edA0
# 5PyHKNL4P5TbBnM4ItLrZ1nTCeUBCQyU3Vi/Prvd/EU9T56ag649SvOdLjeeEMZm
# Rq5JNMD2oN6MMo8DqnptgWlFfkIUL8yHceRmUgHrCFIGlGko6rNZJW8MdRl3k3Hr
# PI7vzM1cRk3WpQwvBiGrhs0ISCf97w9Tz8GU84G0m8/HTSIUqHn3ttNG67xhWXG+
# nSmIWSkPzNfO3MXs3/pjhT3Vk8WzECnlq64XM/ltJt6A49R2APR+XMMXfelc84Lu
# OLGeVYaEGKt5kNq33XAeEcr6FKEZWKGCFxYwghcSBgorBgEEAYI3AwMBMYIXAjCC
# Fv4GCSqGSIb3DQEHAqCCFu8wghbrAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFZBgsq
# hkiG9w0BCRABBKCCAUgEggFEMIIBQAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCCby+/9Q6GV9mEek/U1cpEzyk5DQLk9pvcYN6ZmaE25fgIGYhe2+41U
# GBMyMDIyMDQwOTA0MzUwNC4zOTNaMASAAgH0oIHYpIHVMIHSMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNO
# OjJBRDQtNEI5Mi1GQTAxMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNloIIRZTCCBxQwggT8oAMCAQICEzMAAAGGeOUZifgkS8wAAQAAAYYwDQYJ
# KoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEx
# MDI4MTkyNzM5WhcNMjMwMTI2MTkyNzM5WjCB0jELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3Bl
# cmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjoyQUQ0LTRC
# OTItRkEwMTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAMCNxtlqb+geCIwH64HyaZ3T
# zj2DtWHfPr5X6CMTFt4HQg0/syG2n4NeKTrtLdHpFEMetKez2nR+Do56jSBNaupX
# R/Z7Y9YCHZeB6uK3RB02eiRXRNuA0m1aKqkfkeCMOMNxj233NkN5H8shco/gzoZg
# lsPxWYk1U5U+G3Xo8gFuq/yZ+H698S4274SE2ra9+lcss4ENGOFq+9x94FHC42Lt
# Koh7rQw2+vqfsgwRpihc5zlvMFbew/rtlRCaBOiZStBKVS2brHUs4XnLlMCV8W9r
# soAGV5bGv3x5cFvWJ5QajByfopvR7iuV+MfP+QeXZLiKF+ZVhoxTGw9gOi7vz5lA
# eIStAheRtWGlLQazBO9wwCpMqZO0hJtwZSV8GPxq1aF1mFBhB8n65C5MLNEaBDKa
# CBIHm2TSqo0cp0SYEeHzwiqxIcBIk0wHOA1xnIuBxzpuuBENYP0gxzBaiClUsaFG
# 5Bm3SjSh4ZmobiKwMuMHvbO62SbJL3mWGYg5rQLQbf4EKI8W2dbzvQtdUrYZK5pJ
# EzC0H/XA85VRAXruiph19ks3uoIJ3tyOHMv+SFC5x2d6zOGaSXNLNiqRix2laxEM
# uMf5gJ+MmmH4Hh9zBAFpFY8v6kw4enAwhf4Ms902kA7bxZwCu9C6rWxLwT3QaXgh
# v4ZPZdJWmM8IsshmPx6jAgMBAAGjggE2MIIBMjAdBgNVHQ4EFgQUGbajRQPvZnRL
# v4d91IRzDesIXC4wHwYDVR0jBBgwFoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYD
# VR0fBFgwVjBUoFKgUIZOaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9j
# cmwvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwG
# CCsGAQUFBwEBBGAwXjBcBggrBgEFBQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIw
# MjAxMCgxKS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDAN
# BgkqhkiG9w0BAQsFAAOCAgEAw+5noSWN30xyguIY/sAVgfOeOLmiYjDCB54SvTjU
# zO1a2k2M8dFP03CyeoMcNbUczObrvJLMCTZRzae0XnbAIsL4lUGVfQC/CG2USyU8
# DXoQsJPgVXGNoId2RmZsfLmrT2a0bnsoYU0w9j7xVS638IdpYgxv3RDzSB0yo+/Q
# 5RHDyFqDglKe6dDkTMEPeZFWom6V/Pab44T5dhZtAgTt6V1yYNG8naUOXQw07/6m
# 9PlmBf7zVRFPzKDBEKpVFlrlxAk6sek2sibiyerlOyuUMk5EP5duCIRow83+QBGT
# qyDWM5FlcjX1DqSMZyrFkwTdoo6Wf07p+aq5qPbzSA09JaG4J7pWntezWhDvaIhC
# SR9bUN+d3YbkYvgNND0e/NYmJcxeSVNQ6xHxMjcfAloBEYvdCyrGIIWQQg40Nw4i
# Y31GS6jjXh6yX3Joc+f235vPmgGlD6WRXj9INCKJ3elzZOGImG1jxaKH3NC8HKkg
# C7biAMs+n93flGmWbKeNVOIQiKBo+oaAyLlPN/W6P5mfwIBEsBsSF7NIGVOgPtqi
# FHutEHQPevcFks7nCjorJ4PRwkmSxdXanN0FGsK9AtFONe/OCqPb3JABt2pMGLlR
# nLOoTP0qhIaHvYx8HuF6fNQq0wdZffhCHbpAmz9JMs8dFmc7Xnogzea3YokEfZgS
# bpYwggdxMIIFWaADAgECAhMzAAAAFcXna54Cm0mZAAAAAAAVMA0GCSqGSIb3DQEB
# CwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYD
# VQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAe
# Fw0yMTA5MzAxODIyMjVaFw0zMDA5MzAxODMyMjVaMHwxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0
# YW1wIFBDQSAyMDEwMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA5OGm
# TOe0ciELeaLL1yR5vQ7VgtP97pwHB9KpbE51yMo1V/YBf2xK4OK9uT4XYDP/XE/H
# ZveVU3Fa4n5KWv64NmeFRiMMtY0Tz3cywBAY6GB9alKDRLemjkZrBxTzxXb1hlDc
# wUTIcVxRMTegCjhuje3XD9gmU3w5YQJ6xKr9cmmvHaus9ja+NSZk2pg7uhp7M62A
# W36MEBydUv626GIl3GoPz130/o5Tz9bshVZN7928jaTjkY+yOSxRnOlwaQ3KNi1w
# jjHINSi947SHJMPgyY9+tVSP3PoFVZhtaDuaRr3tpK56KTesy+uDRedGbsoy1cCG
# MFxPLOJiss254o2I5JasAUq7vnGpF1tnYN74kpEeHT39IM9zfUGaRnXNxF803RKJ
# 1v2lIH1+/NmeRd+2ci/bfV+AutuqfjbsNkz2K26oElHovwUDo9Fzpk03dJQcNIIP
# 8BDyt0cY7afomXw/TNuvXsLz1dhzPUNOwTM5TI4CvEJoLhDqhFFG4tG9ahhaYQFz
# ymeiXtcodgLiMxhy16cg8ML6EgrXY28MyTZki1ugpoMhXV8wdJGUlNi5UPkLiWHz
# NgY1GIRH29wb0f2y1BzFa/ZcUlFdEtsluq9QBXpsxREdcu+N+VLEhReTwDwV2xo3
# xwgVGD94q0W29R6HXtqPnhZyacaue7e3PmriLq0CAwEAAaOCAd0wggHZMBIGCSsG
# AQQBgjcVAQQFAgMBAAEwIwYJKwYBBAGCNxUCBBYEFCqnUv5kxJq+gpE8RjUpzxD/
# LwTuMB0GA1UdDgQWBBSfpxVdAF5iXYP05dJlpxtTNRnpcjBcBgNVHSAEVTBTMFEG
# DCsGAQQBgjdMg30BATBBMD8GCCsGAQUFBwIBFjNodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vcGtpb3BzL0RvY3MvUmVwb3NpdG9yeS5odG0wEwYDVR0lBAwwCgYIKwYB
# BQUHAwgwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8G
# A1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQw
# VgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9j
# cmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUF
# BwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3Br
# aS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwDQYJKoZIhvcNAQEL
# BQADggIBAJ1VffwqreEsH2cBMSRb4Z5yS/ypb+pcFLY+TkdkeLEGk5c9MTO1OdfC
# cTY/2mRsfNB1OW27DzHkwo/7bNGhlBgi7ulmZzpTTd2YurYeeNg2LpypglYAA7AF
# vonoaeC6Ce5732pvvinLbtg/SHUB2RjebYIM9W0jVOR4U3UkV7ndn/OOPcbzaN9l
# 9qRWqveVtihVJ9AkvUCgvxm2EhIRXT0n4ECWOKz3+SmJw7wXsFSFQrP8DJ6LGYnn
# 8AtqgcKBGUIZUnWKNsIdw2FzLixre24/LAl4FOmRsqlb30mjdAy87JGA0j3mSj5m
# O0+7hvoyGtmW9I/2kQH2zsZ0/fZMcm8Qq3UwxTSwethQ/gpY3UA8x1RtnWN0SCyx
# TkctwRQEcb9k+SS+c23Kjgm9swFXSVRk2XPXfx5bRAGOWhmRaw2fpCjcZxkoJLo4
# S5pu+yFUa2pFEUep8beuyOiJXk+d0tBMdrVXVAmxaQFEfnyhYWxz/gq77EFmPWn9
# y8FBSX5+k77L+DvktxW/tM4+pTFRhLy/AsGConsXHRWJjXD+57XQKBqJC4822rpM
# +Zv/Cuk0+CQ1ZyvgDbjmjJnW4SLq8CdCPSWU5nR0W2rRnj7tfqAxM328y+l7vzhw
# RNGQ8cirOoo6CGJ/2XBjU02N7oJtpQUQwXEGahC0HVUzWLOhcGbyoYIC1DCCAj0C
# AQEwggEAoYHYpIHVMIHSMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0
# ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjJBRDQtNEI5Mi1GQTAxMSUwIwYD
# VQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoD
# FQABrtg0c1pCpY5l8kl9ZKKxy+HzJ6CBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0
# YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5frkFDAiGA8yMDIyMDQwOTAw
# NDA1MloYDzIwMjIwNDEwMDA0MDUyWjB0MDoGCisGAQQBhFkKBAExLDAqMAoCBQDl
# +uQUAgEAMAcCAQACAhdxMAcCAQACAhEoMAoCBQDl/DWUAgEAMDYGCisGAQQBhFkK
# BAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJ
# KoZIhvcNAQEFBQADgYEAN9oAnPeMrOw4FZ7FoMl09aJqcv0xYUMWnC8JRYr4uzx+
# pns1SkwJLWMd7XVKZfFymhI9PSPmwYozsDb8SEUtv9U6/wXXSvzwg9AMSfFFygQj
# ooxN/7tKFGVHBjg0cDpjvui8nynIRq7dyBilItk77jxQURTMzrMIjV6J76yzcj0x
# ggQNMIIECQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAA
# AYZ45RmJ+CRLzAABAAABhjANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkD
# MQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCDtWudM9zYNdBF+9g9byUUT
# 2K3iQy37+SbHf3QiD7J7vzCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIBqZ
# iOCyLAhUxomMn0QEe5uxWtoLsVTSMNe5nAIqvEJ+MIGYMIGApH4wfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAGGeOUZifgkS8wAAQAAAYYwIgQgXYNy
# XQL5tRcrq2RdGbAP4VHJM1BkaS0tEDgYPOys8m4wDQYJKoZIhvcNAQELBQAEggIA
# e83mHJz9RNraaHISdGD96LxVXqTkptuPHRuIXZg/GOcqAtDqK/bnSSYt0rN297Qf
# woOI+Q+SJpgUF7UqGxxgCIwGDCv1itWrc2STCdoyImJ0JIhjXeeNptJz3LG0InaV
# o154DLeRORGXin2OtL76ipwC/Jqb7/3upcenGW+I2wQSizWY6v8BdZAWfmoWWB7y
# HcCcJmn76209mXvPQFDt9IhnOH5onhkEQNv7jCoCmAqsXLoZBJzzHAegw2MheGSQ
# QdBYs++S97IUaxLgQhyr+BNkmytv5NqpAgEGimcgtC24JKYIv2N32rRtIyylptB9
# +WJgC9f7FACz8KA5M0V34R1z6tn1HBLcIM3H83qMS4NaMUdCtOuY3pjomN8md9Q7
# OhnW/Hc+PGgxd+gtsZ57QuuNZ2fKWBkj+C6chr+4A7hKkQupCvjfm70fECtTummn
# KymsUcKvNf/r1ZrtMm2/uKBQTSS1iz+B551tQ/hayzsAZku5BxAamhd3I//F2w/+
# gvnp5x27rxbNYiXjEdGWkH61ROqbpT/LXkE5tWSfhdceG18svxznKsroPcPPc2aT
# NqE2ATl2jlhxyQAHq1yUczXjBZuGsUMNVCRIRglQs5UrsR2VnZvFB58WiBYFNlNO
# WptnQ4FpJM2gHLAwJW1fpobMUchx0lOG7vVFK2jQ3CA=
# SIG # End signature block
